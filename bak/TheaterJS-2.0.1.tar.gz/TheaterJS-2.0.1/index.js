module.exports = require('./dist/theater.min.js')
